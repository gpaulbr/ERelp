package edu.umass.cs.mallet.projects.seg_plus_coref.coreference;

import com.wcohen.secondstring.*;
import edu.umass.cs.mallet.base.types.*;
import edu.umass.cs.mallet.base.classify.*;
import edu.umass.cs.mallet.base.pipe.*;
import edu.umass.cs.mallet.base.pipe.iterator.*;
import edu.umass.cs.mallet.base.util.*;
import java.util.*;
import java.lang.*;
import java.io.*;


/*
	This class contains various information about an author.  Eventually
	Authors will be first class objects.  Also, we typically have different
	versions of the Authors name that we'd like to keep around pre-parsed
 */
public class Author {

	public Author () {}	


}
