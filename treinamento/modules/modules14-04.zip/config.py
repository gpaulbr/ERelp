
class diretorioTrabalho(object):
	"""docstring for diretorioTrabalho"""
	def __init__(self, diretorioTrabalho):
		self.diretorioTrabalho = diretorioTrabalho
		