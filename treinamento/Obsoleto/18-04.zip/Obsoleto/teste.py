string = "Meu nome eh cristiano Ronaldo e eu uso Clear Man"

string2 = string.strip(' ')
for i in string2:
	print i